# app/main.py
from fastapi import FastAPI
from app.routes import auth

app = FastAPI(title="Social Network API with Neo4j")

app.include_router(auth.router, prefix="/auth", tags=["Auth"])

@app.get("/")
def root():
    return {"message": "Welcome to the Social Network API!"}
