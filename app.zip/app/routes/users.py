# app/routes/users.py
from fastapi import APIRouter, HTTPException, Depends
from app.models.graph_model import create_friendship, get_user_by_email_record, add_interest_to_user, get_user_by_username
from pydantic import BaseModel

router = APIRouter()

class FriendAction(BaseModel):
    friend_email: str
    bidir: bool = True

@router.post("/friend")
def befriend(action: FriendAction):
    if not get_user_by_email_record(action.friend_email):
        raise HTTPException(404, "Friend user not found")
    # Here normally check auth (omitted for brevity). Suppose user comes as param:
    # For demo, use a fixed acting user email (in real: get from token)
    acting_email = "alice@example.com"
    create_friendship(acting_email, action.friend_email, action.bidir)
    return {"status": "ok", "friend_with": action.friend_email}

class InterestIn(BaseModel):
    interest: str
@router.post("/interest")
def add_interest(data: InterestIn):
    acting_email = "alice@example.com"
    add_interest_to_user(acting_email, data.interest)
    return {"status":"ok", "interest": data.interest}
