# app/routes/auth.py
from fastapi import APIRouter, HTTPException
from app.schemas.user_schema import UserCreate, UserOut
from app.models.user_model import create_user, get_user_by_email
from app.utils.auth_utils import hash_password, verify_password, create_access_token

router = APIRouter()

@router.post("/register", response_model=UserOut)
def register(user: UserCreate):
    if get_user_by_email(user.email):
        raise HTTPException(status_code=400, detail="Email already registered")

    hashed = hash_password(user.password)
    create_user(user.username, user.email, hashed)
    return {"username": user.username, "email": user.email}


@router.post("/login")
def login(user: UserCreate):
    record = get_user_by_email(user.email)
    if not record:
        raise HTTPException(status_code=404, detail="User not found")

    user_node = record["u"]
    if not verify_password(user.password, user_node["password"]):
        raise HTTPException(status_code=401, detail="Invalid credentials")

    token = create_access_token({"sub": user_node["email"]})
    return {"access_token": token, "token_type": "bearer"}
