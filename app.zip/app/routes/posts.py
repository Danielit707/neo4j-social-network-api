# app/routes/posts.py
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from app.models.graph_model import create_post, comment_on_post

router = APIRouter()

class PostIn(BaseModel):
    content: str
    media_url: str = None

@router.post("/post")
def post_create(data: PostIn):
    acting_email = "alice@example.com"
    p = create_post(acting_email, data.content, data.media_url)
    return {"status":"ok", "post": dict(p["p"]) if p else None}

class CommentIn(BaseModel):
    post_id: str
    content: str

@router.post("/comment")
def comment(data: CommentIn):
    acting_email = "alice@example.com"
    c = comment_on_post(acting_email, data.post_id, data.content)
    return {"status":"ok", "comment": dict(c["c"]) if c else None}
